<?php
/*
* 
*  Template Name: Index
*/
?>


<?php get_header(); ?>

<body>

    <!--  header -->
    <Header>

        <nav class="navbar navbar-expand-lg ">
            <a class="navbar-brand" href="#">
                <img src="<?php bloginfo('template_url'); ?>/asset/res/imgs/logo.png" class="d-inline-block align-top" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
                aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">

                </ul>
                <ul class="navbar-nav  my-2 my-lg-0">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">LOG IN <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">SIGN UP</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">
                            <img src="<?php bloginfo('template_url'); ?>/asset/res/imgs/band.png" height="15px" width="15px" alt="">
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="slider">
            <h2 class="slider-header-1"><?php the_field('titre',113); ?></h2>
            <h1 class="slider-header-2"><?php the_field('sous-titre',113); ?></h1>

            <p class="slider-btn">
                <a href="#" class="btn btn-lg btn-outline-light">GET STARTED</a>
            </p>
            <p class="slider-footer"><?php   the_field('text',113); ?></p>
        </div>


    </Header>

    <!-- end header -->

    <!-- section 1 -->

    <section id="section-1" class="row">


        <div class="box col-xs-4 col-sm-4 col-md-4 col-lg-4">

            <img src="<?php the_field('image_1',134); ?>" alt="" srcset="">
            <h2><?php the_field('titre_1',134); ?></h2>
            <hr>
            <p class="box-content"><?php the_field('description_1',134); ?></p>

        </div>
        <div class="box col-xs-4 col-sm-4 col-md-4 col-lg-4">

            <img src="<?php the_field('image_2',134); ?>" alt="" srcset="">
            <h2><?php the_field('titre_2',134); ?></h2>
            <hr>
            <p class="box-content"><?php the_field('description_2',134); ?></p>

        </div>
        <div class="box col-xs-4 col-sm-4 col-md-4 col-lg-4">

            <img src="<?php  the_field('image_3',134); ?>" alt="" srcset="">
            <h2><?php  the_field('titre_3',134); ?></h2>
            <hr>
            <p class="box-content"><?php  the_field('description_3',134); ?></p>

        </div>


    </section>

    <!-- end section 1 -->


    <!-- section 2 -->
    <section id="section-2" class="row">


        <div class="box-iphone col-xs-6 col-sm-6 col-md-6 col-lg-6">

        </div>
        <div class="box-detail col-xs-6 col-sm-6 col-md-6 col-lg-6">
            <div class="box-detail-header">
                <h2><?php the_field('titre',141); ?></h2>
                <hr>
            </div>
            <p class="box-detail-content">
            <?php the_field('description',141); ?>
            </p>
            <div class="box-detail-footer">
                <a href="<?php the_field('lien_app_store',141); ?>">
                    <img src="<?php bloginfo('template_url'); ?>/asset/res/imgs/Untitled-2.png" alt="" srcset="">
                </a>
                <a href="<?php the_field('lien_play_store',141); ?>">
                    <img src="<?php bloginfo('template_url'); ?>/asset/res/imgs/app_store.png" alt="" srcset="">
                </a>
            </div>
        </div>

    </section>
    <!-- end section 2 -->

    <!-- section 3 -->

    <section id="section-3">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
            
                <?php 

                    $args = array( 'post_type' => 'Review', 'posts_per_page' => 10 );
                    $loop = new WP_Query( $args );

                    $i= 0;

                    if($loop->have_posts()) { 

                        while($loop->have_posts()) : $loop->the_post();
                         ?>
                        <div class=" carousel-item <?php if($i==0){echo 'active';} ?> ">
                        <div class="box-review">
                            <img class="box-review-img" src="<?php the_field('image') ?>" alt="" srcset="">
                            <p class="box-review-text">“<?php the_field('text') ?>”</p>
                            <p class="box-review-titel">- <?php the_field('name') ?> -</p>
                        </div>
                    </div>
                <?php   
                    $i++;
                 endwhile; }
                 wp_reset_postdata(); ?>

                
                
                
            </div>

        </div>
    </section>

    <!-- end section 3 -->

    <!-- section 4 -->

    <section id="section-4">

        <p class="box-cuisines-titel">BROWSE BY CUISINES</p>
        <hr>

        <?php 

            $args = array( 'post_type' => 'Cuisins', 'posts_per_page' => 10 );
            $loop = new WP_Query( $args );

            $i= 0;

            if($loop->have_posts()) { 

                while($loop->have_posts()) : $loop->the_post();

                if($i==0)
                {
                    echo '<div class="box-cuisines">';
                    
                }

                ?>
                        <div class="box-cuisines-item" style="background: url('<?php the_field('image_1'); ?>') no-repeat center center;">
                            <p class="box-cuisines-item-number"><?php the_field('number_1'); ?> Recipes</p>
                            <p class="box-cuisines-item-name"><?php the_field('text_1') ?></p>
                        </div>
                    
            <?php   
                if($i==4)
                {
                    $i=0;
                    echo '</div>';
                }
                else
                    $i++;

                endwhile; 

                if($i!=0 )  echo '</div>' ;

            }
            wp_reset_postdata(); 

            ?>

        


    </section>

    <!-- end section 4 -->

    <!-- section 5 -->

    <section id="section-5">

        
        <div class="box-number">
            <p class="box-number-number">
                <?php if ( is_active_sidebar( 'recipes_available' ) ) : ?>
                    <?php dynamic_sidebar( 'recipes_available' ); ?>
                <?php endif; ?>
            </p>
            <p class="box-number-name">Recipes Available</p>
        </div>
        <div class="box-number">
            <p class="box-number-number">
                <?php if ( is_active_sidebar( 'active_users' ) ) : ?>
                    <?php dynamic_sidebar( 'active_users' ); ?>
                <?php endif; ?>
            </p>
            <p class="box-number-name">Active Users</p>
        </div>
        <div class="box-number">
            <p class="box-number-number">
                <?php if ( is_active_sidebar( 'positive_reviews' ) ) : ?>
                    <?php dynamic_sidebar( 'positive_reviews' ); ?>
                <?php endif; ?>
            </p>
            <p class="box-number-name">Positive Reviews</p>
        </div>
        <div class="box-number">
            <p class="box-number-number">
                <?php if ( is_active_sidebar( 'photos_videos' ) ) : ?>
                    <?php dynamic_sidebar( 'photos_videos' ); ?>
                <?php endif; ?>
            </p>
            <p class="box-number-name">Photos & Videos</p>
        </div>
        <div class="box-number">
            <p class="box-number-number">
                <?php if ( is_active_sidebar( 'recipes_available' ) ) : ?>
                    <?php dynamic_sidebar( 'recipes_available' ); ?>
                <?php endif; ?>
            </p>
            <p class="box-number-name">Spices and Herbs</p>
        </div>
        
    </section>

    <!-- end section 5 -->

<?php get_footer(); ?>