<footer>

    <?php if ( is_active_sidebar( 'footer_1' ) ) : ?>
        <?php dynamic_sidebar( 'footer_1' ); ?>
    <?php endif; ?>

    <div class="footer-2"> 
        <p>DESIGN BY:</p>
        <a href="https://WWW.BEKADES.COM" style="color:black">WWW.BEKADES.COM</a>
    </div>
</footer>

</body>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
    crossorigin="anonymous"></script>
<script src="<?php bloginfo('template_url'); ?>/asset/js/bootstrap.min.js"></script>

<?php wp_footer(); ?>

</html>

