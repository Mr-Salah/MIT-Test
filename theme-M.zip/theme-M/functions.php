<?php
function intia_widget()
{
    register_sidebar( array(
		'name'          => 'footer_1',
		'id'            => 'footer_1',
		'before_widget' => '<div class="footer-1">',
		'after_widget'  => '</div>',
		'before_title'  => '',
		'after_title'   => '',
		) );
		
		////// Cuisinses ///////
    
    register_sidebar( array(
		'name'          => 'Recipes Available',
		'id'            => 'recipes_available',
		'before_widget' => '<div class="box-number-number">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="rounded">',
		'after_title'   => '</h2>',
		) );
		
		register_sidebar( array(
			'name'          => 'Active Users',
			'id'            => 'active_users',
			'before_widget' => '<div class="box-number-number">',
			'after_widget'  => '</div>',
			'before_title'  => '<h2 class="rounded">',
			'after_title'   => '</h2>',
			) );


    register_sidebar( array(
			'name'          => 'Positive Reviews ',
			'id'            => 'positive_reviews',
			'before_widget' => '<div class="box-number-number">',
			'after_widget'  => '</div>',
			'before_title'  => '<h2 class="rounded">',
			'after_title'   => '</h2>',
			) );

		register_sidebar( array(
			'name'          => 'Photos Videos',
			'id'            => 'photos_videos',
			'before_widget' => '<div class="box-number-number">',
			'after_widget'  => '</div>',
			'before_title'  => '<h2 class="rounded">',
			'after_title'   => '</h2>',
			) );

		register_sidebar( array(
			'name'          => 'Spices and Herbs',
			'id'            => 'spices_and_herbs ',
			'before_widget' => '<div>',
			'after_widget'  => '</div>',
			'before_title'  => '<h2 class="rounded">',
			'after_title'   => '</h2>',
			) );
			
							
    
}

add_action( 'widgets_init', 'intia_widget' );


// Add Custom Post Type .


function create_post_type() {
	register_post_type( 'Review',
	  array(
		'labels' => array(
		  'name' => __( 'Reviews' ),
		  'singular_name' => __( 'Review' ),
		  'edit_item' => 'Edite Review',
		  'add_new_item' => 'New Review',
		  'add_new' => 'New Review',
		),
		'public' => true,
		'has_archive' => true,
		
	  )
	);

	register_post_type( 'Cuisins',
			array(
			'labels' => array(
				'name' => __( 'Cuisins' ),
				'singular_name' => __( 'Cuisin' ),
				'edit_item' => 'Edite Cuisin',
				'add_new_item' => 'New Cuisin',
				'add_new' => 'New Cuisin',
			),
			'public' => true,
			'has_archive' => true,
			
			)
		);
		
	}
	
	add_action( 'init', 'create_post_type' );
